import getUser from './login'

function index(state={}, action) {
    return state
}

export  default {
    index,
    getUser
}