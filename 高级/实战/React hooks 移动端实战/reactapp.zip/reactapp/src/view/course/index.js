import React from 'react'

function Course() {
    return (
        <h1>课程</h1>
    )
}

export default Course