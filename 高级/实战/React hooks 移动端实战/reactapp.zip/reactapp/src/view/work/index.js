import React from 'react'

function Work() {
    return (
        <h1>作品</h1>
    )
}

export default Work