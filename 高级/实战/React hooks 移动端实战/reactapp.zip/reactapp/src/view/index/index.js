import React from 'react'
import Tab from '../../common/component/tab'
import '../../common/css/index.css'

let imgData = [
    require('../../common/images/tab/img1.png'),
    require('../../common/images/tab/img2.png'),
    require('../../common/images/tab/img3.png'),
    require('../../common/images/tab/img4.png')
]

function Index(props) {
    return (
        <div>
            <Tab
                data = {imgData}
                render = {(data) => {
                    return <img src={data} />
                }}
            />
        </div>
    )
}

export default Index