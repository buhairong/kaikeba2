import React from 'react'

function Lecturer() {
    return (
        <h1>讲师</h1>
    )
}

export default Lecturer